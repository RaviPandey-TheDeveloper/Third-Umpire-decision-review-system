
# Tkinter gui starts here
window = tkinter.